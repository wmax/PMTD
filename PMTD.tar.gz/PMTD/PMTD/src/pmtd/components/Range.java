package pmtd.components;

import com.artemis.Component;

public class Range extends Component {
	public int range;
	
	public Range(int amount) {
		range = amount;
	}
}
