package pmtd.components;

import com.artemis.Component;

public class Direction extends Component {
	public float dir;

	public Direction(float direction) {
		dir = direction;
	}
}