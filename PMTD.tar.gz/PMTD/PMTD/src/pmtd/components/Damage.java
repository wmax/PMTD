package pmtd.components;

import com.artemis.Component;

public class Damage extends Component {
	public int amount;
	
	public Damage(int amount) {
		this.amount = amount;
	}
}
